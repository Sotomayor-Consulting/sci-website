---
title: "How Stripe Tax Works: Complete Guide 2026"
description: "How Stripe Tax works"
cardImage: "@/images/insights/como-funciona-stripe-tax.avif"
cardImageAlt: "Stripe Tax dashboard showing tax calculation and fiscal reports"
---

**Stripe Tax** is a built-in Stripe tool that calculates, collects, and reports taxes like VAT, GST, and sales tax automatically on your transactions. You no longer need to integrate third-party services or calculate taxes manually.

In this guide, we explain **how Stripe Tax works** in 2026: activation, configuration, supported countries, and best practices.

## 1. What Is Stripe Tax?

### Definition

Stripe Tax is a Stripe module that automates tax calculation and collection on every transaction. It detects the buyer's location, applies the correct tax rate, and generates reports for your tax filing.

### What Stripe Tax Does

- **Calculates taxes:** Correct rate based on product and customer location
- **Collects taxes:** Adds tax to the total amount at checkout
- **Reports:** Generates detailed reports for your accountant
- **Updates rates:** Tax rates updated automatically
- **Multi-jurisdiction:** VAT, GST, sales tax, etc.
### What Stripe Tax Does NOT Do

- **Doesn't file taxes:** You must submit your tax returns
- **Doesn't pay taxes:** You are responsible for paying tax authorities
- **Doesn't replace an accountant:** Always consult with a professional
> **Stripe Tax simplifies calculation**, but it does not replace professional tax advice. Always consult your accountant.

## 2. Why Use Stripe Tax?

### Key Benefits

- **Automation:** Stripe calculates taxes on every sale without manual intervention
- **Accuracy:** Rates updated in real-time based on customer location
- **Time savings:** Eliminates spreadsheets and manual calculations
- **Global coverage:** Supports 100+ countries and all US states
- **Native integration:** No plugins or external services needed
- **Ready reports:** Exportable data for your tax filing
### Stripe Tax vs Alternatives

- **Stripe Tax:** 0.5% per transaction (or free with Stripe Billing) -- Native
- **TaxJar:** From $19/month -- External API
- **Avalara:** From $100/month -- External API
- **Manual:** Hours of work + error risk -- N/A
> **Stripe Tax is the simplest option** if you already use Stripe. It activates with a few clicks and requires no additional development.

## 3. How to Activate Stripe Tax

### Step 1: Check Availability

Stripe Tax is available in:

- **United States:** Sales tax (all taxing states)
- **European Union:** VAT
- **United Kingdom:** VAT
- **Switzerland:** VAT
- **Canada:** GST/HST
- **Australia:** GST
- **New Zealand:** GST
- **Singapore:** GST
- **Japan:** Consumption Tax
- **Norway:** VAT
- **South Africa:** VAT
### Step 2: Activate Stripe Tax in Dashboard

1. Stripe Dashboard → Products → Stripe Tax
2. Click **Activate Stripe Tax**
3. Configure your registration country and tax details
4. Define product categories

### Step 3: Configure Your Tax Settings

- **Origin country:** Where your business is registered
- **Tax number:** EIN, VAT ID, or equivalent
- **Product categories:** Classify your products (digital, physical, service)
- **Exemptions:** Configure if you sell to businesses with valid VAT ID
## 4. Product Categories and Rates

### Tax Categories in Stripe

- **Digital products:** Software, courses, eBooks, downloads -- Taxable in most countries
- **Physical products:** Clothing, books, electronics -- Taxable, rate varies by country
- **Services:** Consulting, coaching, design -- Taxable in some countries
- **Subscriptions:** SaaS, memberships -- Taxable per product type
- **Exempt products:** Accredited education, healthcare -- Not taxable
### How to Assign Categories

### Example Rates by Country

- **United Kingdom:** 20% VAT -- 20% VAT
- **Canada:** 5% GST/HST -- 5% GST/HST + provincial
- **Australia:** 10% GST -- 10% GST
- **Mexico:** 16% IVA -- 16% IVA
- **Brazil:** Variable -- Variable ICMS
- **US (California):** 0% (digital) -- 7.25%+
- **Japan:** 10% Consumption Tax -- 10% Consumption Tax
- **Singapore:** 9% GST -- 9% GST
> **Note:** Rates may vary by product and exact location. Stripe Tax updates rates automatically.

## 5. Stripe Tax at Checkout

### How Tax Is Displayed to the Customer

During checkout, Stripe Tax:

1. Detects the customer's location by IP or shipping address
2. Calculates the correct tax rate
3. Shows the breakdown: subtotal + tax = total
4. Collects the tax along with the product

### Visual Example at Checkout

### Integration Code

## 6. Stripe Tax for Subscriptions

### Recurring Billing with Taxes

Stripe Tax also works with subscriptions:

- **Subscription creation:** Tax on first payment
- **Monthly renewal:** Tax on each renewal
- **Plan upgrade:** Tax adjusted automatically
- **Country change:** Stripe detects new rate if customer moves
- **One-time invoice:** Tax calculated per item
### Example: SaaS Subscription

## 7. Reports and Tax Filing

### Reports Generated by Stripe Tax

- **Tax summary:** Total taxes collected by period
- **Country breakdown:** Taxes collected in each jurisdiction
- **Rate breakdown:** Amount per tax rate
- **Transactions:** Detailed list of transactions with taxes
- **Invoices:** Invoices with itemized taxes
### How to Access Reports

1. Stripe Dashboard → Stripe Tax → Reports
2. Select the period (month, quarter, year)
3. Filter by country, product, or rate
4. Export to CSV for your accountant

### Preparing for Your Tax Filing

## 8. Stripe Tax by Region

### European Union (VAT)

- **Germany:** 19% -- 7%
- **France:** 20% -- 10% / 5.5%
- **Italy:** 22% -- 10% / 5%
- **Spain:** 21% -- 10% / 4%
- **Netherlands:** 21% -- 9%
- **Portugal:** 23% -- 13% / 6%
**Special EU rules:**
- **B2C sales:** Apply customer's country VAT
- **B2B sales (business):** Don't charge VAT if customer has valid VAT ID
- **Thresholds:** Each country has an annual registration threshold

### United States (Sales Tax)

- **California:** 7.25% -- + up to 3% local
- **Texas:** 6.25% -- + up to 2% local
- **New York:** 4% -- + up to 4.875% local
- **Florida:** 6% -- + up to 1.5% local
- **Washington:** 6.5% -- + up to 4% local
**Special US rules:**
- **Nexus:** Only charge sales tax in states where you have physical presence
- **Digital products:** Many states don't tax digital products
- **Marketplaces:** If selling on marketplaces, they may collect tax

### Latin America

- **Mexico:** IVA -- 16%
- **Brazil:** ICMS / ISS -- Variable (7-18% interstate)
- **Chile:** IVA -- 19%
- **Colombia:** IVA -- 19%
- **Argentina:** IVA -- 21%
- **Peru:** IGV -- 18%
## 9. Frequently Asked Questions

### Does Stripe Tax work with all currencies?

Yes. Stripe Tax calculates tax in the customer's local currency. If you charge in another currency, Stripe converts the tax.

### Can I exempt B2B customers?

Yes. Configure Stripe Tax to validate VAT IDs. If the customer enters a valid VAT ID, Stripe won't charge VAT.

### Does Stripe Tax file my taxes for me?

No. Stripe Tax calculates and collects, but you must file and pay taxes to the tax authorities.

### What happens if a rate changes?

Stripe Tax updates rates automatically. You don't need to do anything.

### Does Stripe Tax support local taxes?

Yes. In the US, Stripe Tax supports state and local taxes. In other countries, it supports national and regional rates.

## 10. Quick Step-by-Step

### Summary in 5 Steps

- **1:** Activate Stripe Tax in your Dashboard -- 5 min
- **2:** Configure your country and tax number -- 10 min
- **3:** Assign tax categories to your products -- 15 min
- **4:** Enable `automatic_tax` in your integration -- 10 min
- **5:** Review monthly reports for your filing -- 15 min/month
### Setup Checklist

- [ ] Stripe Tax activated in Dashboard
- [ ] Registration country configured
- [ ] Tax number added (VAT ID, EIN, etc.)
- [ ] Tax categories assigned to each product
- [ ] `automatic_tax: { enabled: true }` in code
- [ ] B2B exemptions configured (if applicable)
- [ ] Tax reports reviewed
- [ ] Consulted with accountant on local obligations

## Conclusion

**Stripe Tax** dramatically simplifies tax calculation and collection on your online sales. With minimal configuration, you can meet tax obligations in 100+ countries without integrating external services or calculating rates manually.

Remember that Stripe Tax calculates and collects, but filing and paying taxes remains your responsibility. Always consult a professional accountant.

At **Sotomayor Consulting International**, we advise online businesses on Stripe Tax setup and international tax compliance, including US company formation to optimize your tax structure. Contact us for personalized consulting.
